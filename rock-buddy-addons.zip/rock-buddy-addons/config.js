// Host to listen for addon data
// Leave this set to localhost if you are running addons on the same PC as Rock Buddy
const addonsHost = 'localhost';

// Port to listen for addon data
const addonsPort = 9001;
